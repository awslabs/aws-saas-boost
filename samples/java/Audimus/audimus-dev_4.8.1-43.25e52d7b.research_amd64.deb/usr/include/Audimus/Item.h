#ifndef ITEM_H_
#define ITEM_H_

#include <string>

namespace audimus {

class Item
{
public:
	Item() {
		_eof = false;
		_eos = false;
		_autoPause = false;
	};
	virtual ~Item() {};
	
	bool isEOF() { return _eof; };
	bool isEOS() { return _eos; };
	bool isAutoPause() { return _autoPause; };
	
	void setEOF(bool status) { _eof = status; };
	void setEOS(bool status) { _eos = status; };
	void setAutoPause(bool status) { _autoPause = status; };
	
	virtual Item* clone() {
		Item* item = new Item();
		item->setEOF(this->isEOF());
		item->setEOS(this->isEOS());
		item->setAutoPause(this->isAutoPause());
		return item;
	};
	
	virtual std::string toString() {return "";}; 
	
protected:
	bool _eof;
	bool _eos;
	bool _autoPause;
};

} //namespace audimus

#endif /*ITEM_H_*/
