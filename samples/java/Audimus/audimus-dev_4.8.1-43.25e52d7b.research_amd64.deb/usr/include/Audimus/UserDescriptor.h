#ifndef _USER_DESCRIPTOR_H_
#define _USER_DESCRIPTOR_H_

//STL includes
#include <string>

namespace audimus {

/**
 * Classe que define um modelo acustico
 */
class  UserDescriptor {
private:

	//Paths dos ficheiros que definem o modelo
	std::string mlpPath;
	std::string mlpIndex;
	std::string weightsPath;
	std::string statsPath;
	std::string priorsPath;

	//Nome do modelo acustico
	std::string name;
	
	//Variavel que indica se o modelo est� em uso
	bool loaded;

	// Indicates if we have a new arch
	bool isNew;
	
	//Nome do componente ao qual se destina este modelo acustico
	std::string _owner;
	
	//Component type of the owner
	std::string _ownerType;

public:
	//Construtor
	UserDescriptor(std::string modelName) {
		//Inicializa��o dos membros da classe
		name = modelName;
		loaded = false;

		mlpPath = "";
		mlpIndex = "";

		isNew = false;

		weightsPath = "";
		statsPath = "";
		priorsPath = "";
		_owner = "";
		_ownerType = "";
	}
	
	//Destrutor
	~UserDescriptor() {};
	
	//Setters
	void setMLP(std::string filePath)    { mlpPath = filePath; };
	void setMLPIndex(std::string index)    { mlpIndex = index; }; // selects which model inside the MLP file will be used

	void setWeights(std::string filePath)    { weightsPath = filePath; };
	void setStats(std::string filePath)      { statsPath = filePath; };
	void setPriors(std::string filePath)     { priorsPath = filePath; };

	void setOwner(std::string owner)		 { _owner = owner; };
	void setOwnerType(std::string type)		 { _ownerType = type; };

	//Getters
	std::string getMLP () 	 { return mlpPath; };
	std::string getMLPIndex () 	 { return mlpIndex; };

	std::string getWeights() 	 { return weightsPath; };
	std::string getStats()   	 { return statsPath; };
	std::string getPriors() 	 { return priorsPath; };

	std::string getName()        { return name; };
	std::string getOwner()        { return _owner; };
	std::string getOwnerType()        { return _ownerType; };


	//Query
	bool isLoaded()			 { return loaded; };
	bool isNewArch () 		 { return (mlpPath != "") ? true : false; };
	bool isValid();
	
	std::string toString() {
		std::string res(name);
		res += "\n";
		res += "\t Weights: " + getWeights() + "\n";
		res += "\t Stats: "+ getStats() + "\n";
		res += "\t Priors: " + getPriors() + "\n";
		return res;
	};
};

} //namespace audimus

#endif //_USER_DESCRIPTOR_H_
