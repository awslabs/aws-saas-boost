#ifndef _INPUT_BUFFER_H
#define _INPUT_BUFFER_H

//STL includes
#include <string>

//Audimus includes
#include "Item.h"

namespace audimus {

/**
 * Input buffer
 *	- Used for components read data
 */
class InputBuffer
{
protected:
	int _frameBodySize;
public:
	InputBuffer (int frameBodySize) {
		_frameBodySize = frameBodySize;
	};
	virtual ~InputBuffer(){};

	virtual int getBodySize () { return _frameBodySize; }
	virtual int getFloatBodySize () { return (int)(_frameBodySize / sizeof (float)); }
	virtual int getShortBodySize () { return (int)(_frameBodySize / sizeof (short)); }
	virtual long clear () = 0;

	/**
	 * M�todo que remove todas as frames que estejam em mem�ria
	 * deixando apenas uma frame que indica o fim de frase ( frameID = -1)
	 * 
	 * @TODO This should be abstract
	 */
	virtual void flush(bool autoPause = false) = 0;
	
	virtual Item* read() = 0;

	/**
	 * Returns the next element to be read, without removing it
	 * from input queue
	 */
	virtual Item* peek() { return NULL; };

	//Controls start and stop of underlying activity
	virtual bool start() { return true; };
	virtual bool stop() { return true; };
	
	virtual int available() = 0;
};

} //namespace audimus

#endif //_INPUT_BUFFER_H
