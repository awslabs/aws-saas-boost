#ifndef _EVENT_DECODER_RESULT_H
#define _EVENT_DECODER_RESULT_H

#include "DecoderResult.h"
#include "Event.h"

namespace audimus {

class EventDecoderResult : public Event
{
protected:
	DecoderResult *_result; // sentence decoded

public:
	EventDecoderResult(int id, DecoderResult* pt):Event(id) {
		_result = pt;
	};

	virtual ~EventDecoderResult() {
		delete _result;
		_result = NULL;
	};
	DecoderResult *getResult() {return _result;};
};

} //namespace audimus

#endif /* _EVENT_DECODER_RESULT_H */
