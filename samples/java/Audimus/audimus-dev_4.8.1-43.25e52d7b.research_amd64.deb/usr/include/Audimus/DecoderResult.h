//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;-*-mode:-*-
//;;;
//;;; Copyright (c) 1999,2000,2001,2002,2003,2004 L2F (INESC-ID LISBOA)
//;;; All Rights Reserved.
//;;;
//;;; THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF L2F (INESC-ID LISBOA)
//;;; The copyright notice above does not evidence any
//;;; actual or intended publication of such source code.
//;;;
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
//;;;
//;;; This file is part of the Audimus system
//;;; This file is part of the FSTk Library
//;;;
//;;;
//;;; Author: Diamantino Caseiro      (Diamantino.Caseiro@l2.inesc-id.pt)
//;;; Author: Renato Cassaca          (rmfc@l2.inesc-id.pt)
//;;;
//;;; 1999->2004 dcaseiro Algorithm
//;;; xx-10-2004 rmfc Windows Port
//;;;
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

#ifndef _DECODER_RESULT_H
#define _DECODER_RESULT_H


#include <string>
#include <sstream>
#include <limits>
#include <limits.h>
#include <map>
#include <fstream>
#include <list>
#include <vector>
#include <string.h> /*Added by Alberto*/
#include <cstdlib>
#include <cmath>
#include <memory>
#include <chrono>

#include "CDecodedPhoneInfo.h"
#include "CDecodedWordInfo.h"
#include "XMLEscape.h"

//Markers in result that identify a tag
#define TAG_START '<'
#define TAG_END   '>'

//#define XML_HEADER "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\r\n";
#define XML_LATIN1_HEADER "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n";
#define XML_UTF8_HEADER "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n";

namespace audimus {





//////////////////////////////////////////////////////////////
//
// this is the structure used to produce the recognition output
//

class DecoderResult {
 protected:
  int _sentence_id; // number of the current utterance
  int _hypothesis_id; // number of the current hypothesis in this sentence (0 ->first, -1 -> last)
  int _model_id;	// id of the current model
  unsigned int _nWords;      // number of decoded words
  unsigned int _nSureWords;  // number of words common to all alternatives
  unsigned int _nTags;       // number of tags
  unsigned int _nSureTags;   // number of tags common to all alternatives
  unsigned int _nPhones;     // number of decoded phones
  bool         _isnorm;      // Normalization flag

  int _numFrames;  //Number of frames that produced this result

  CDecodedPhoneInfo *_phones;  // decoded phone sequence
  CDecodedWordInfo  *_words;   // decoded word  sequence

  long _sentenceStartTime; //Sentence absolute Start Time
  long _sentenceEndTime;   //Sentence absolute End time </s>

  std::string _taskName;

  std::string _resultText;
  
  float _resultConfidence;
  double _latency;

  char* _audio;
  long  _audioSize;

  float* _features;
  long _featuresSize;

  int* _targets;
  long _targetsCount;

  float _tok_cost;

  int _genderId;
  float _genderConf;

  int _speakerId;
  float _speakerIdConf;
  std::string _speakerName;
  std::string _speakerHash;
  int _speakerTurn;
  bool _speakerKnown;

  std::string _langId;
  float _langIdConf;

  DecoderResult* _next_nbest_list;

  std::string _nlsmlIntepretation;

  bool _isDTMFResult;

  //Indicates if this DecoderResult is a final or a hypothesis
  bool _final;

 public:

  DecoderResult();

  // construction functions (called by the decoder)
  void setResult(int nphones, CDecodedPhoneInfo *phones, int nwords, CDecodedWordInfo *words, int nsurewords, int ntags, int nsuretags);

  void setNextNBestList( DecoderResult* next) {
	  _next_nbest_list = next;
  };

  std::list<DecoderResult*> getNBests()
  {
	  std::list<DecoderResult*> nBests;

	  DecoderResult* dr = this;
	  while (dr->_next_nbest_list != NULL)
	  {
		  nBests.push_back(dr);
		  dr = dr->_next_nbest_list;
	  }

	  return nBests;
  }

  void setSentenceId (int id)
    {_sentence_id = id;};
  int getSentenceId()
    {return _sentence_id;};

  void setHypothesisId (int id)
      {_hypothesis_id = id;};
  int getHypothesisId()
      {return _hypothesis_id;};

  int getModelId() {
	return _model_id; 
  }

  void setModelId ( int id ) {
	_model_id = id; 
  }

  void setNumberOfFrames(int numFrames) { _numFrames = numFrames; };
  int getNumberOfFrames() { return _numFrames; };

  void setFinal(bool status) { _final = status; };
  bool isFinal() { return _final; };

 // access functions

  int nWords() { return _nWords;};
  int nSureWords() { return _nSureWords;};

  void setNSureWords(int nSureWords) { _nSureWords = (nSureWords < 0) ? 0 : nSureWords;};

  std::string getResultText(bool outputUTF8 = false) {
	  if ((outputUTF8 == true) && (_resultText.size() > 0)) {
		  std::string utf8Result = Latin1toUTF8(_resultText.c_str());
		  return utf8Result;
	  }
	  else {
		  return _resultText;
	  }
  };
  float getResultConfidence() { return _resultConfidence; };

  void setResultConfidence ( float confidence ) { _resultConfidence = confidence ; };

  void setNLSMLInterpretation ( std::string interpretation ) {
	  _nlsmlIntepretation = interpretation;

  }

  std::string getNLSMLResult(bool outputUTF8 = false) { return getNLSMLResult(getTaskName(), outputUTF8); };

  std::string getNLSMLResult(std::string taskName, bool outputUTF8 = false)
  {
	//Build a basic interpretation, based on tags
	int confidence = rndFloat(_resultConfidence * 100);  //NLSML confidence is between 0-100

	//Initialize NLSML XML string
	std::ostringstream result;
	if (outputUTF8 == true) {
		result << XML_UTF8_HEADER;
	}
	else {
		result << XML_LATIN1_HEADER;
	}
	result << "<result grammar=\"" << XMLEscape(taskName) << "\">\r\n";
	result << "  <interpretation grammar=\"" << XMLEscape(taskName) << "\" confidence=\"" << confidence << "\">\r\n";

	//Grammar mode that produced this result
	std::string grammarMode = _isDTMFResult ? "dtmf" : "speech";

	//Check that result is non-empty
	if ((_resultText.empty() == true) && (_nlsmlIntepretation.length() < 1))
	{
		result << "    <instance/>\r\n";
		result << "    <input mode=\"" << XMLEscape(grammarMode) << "\" confidence=\"" << confidence << "\"><nomatch/></input>\r\n";
	}
	else
	{
		//Non-empty result
		result << "    <instance>\r\n";
		if (_nlsmlIntepretation.empty() == false) {
			result << "      " << XMLEscape(_nlsmlIntepretation);
		}
		result << "    </instance>\r\n";
		result << "    <input mode=\"" << XMLEscape(grammarMode) << "\" confidence=\"" << confidence << "\">" << _resultText << "</input>\r\n";
	}

	//Finalize NLSML string
	result << "  </interpretation>\r\n";
	result << "</result>\r\n";

	std::string nlsmlLatin1Result = result.str();
	result.str("");

	//Convert result to UTF-8 if needed (because internal format is iso-8859-1
	if (outputUTF8 == true) {
		std::string nlsmlUTF8Result = Latin1toUTF8(nlsmlLatin1Result.c_str());
		return nlsmlUTF8Result;
	}
	else {
		return nlsmlLatin1Result;
	}
  };

  int nTags() { return _nTags;};
  int nSureTags() { return _nSureTags;};

  int labelAt(unsigned int index)
    { return (_words && (index < _nWords)) ? _words[index].f_word : kNoLabel; };

  std::string wordAt(unsigned int index)
	{ return (_words && (index < _nWords)) ? _words[index].f_word_string : ""; };

  bool isControlWord(unsigned int index)
  {
	  return (_words && (index < _nWords)) ? _words[index].isControlWord() : false;
  }

  bool hasCap(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_cap.empty(); } else return false; };
  void setCapAt(unsigned int index, std::string cap)
  	{ if (_words && (index < _nWords)) _words[index].f_word_cap = cap; };
  std::string capAt(unsigned int index)
  	{ return (_words && (index < _nWords)) ? _words[index].f_word_cap : ""; };

  bool hasPunct(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_punct.empty(); } else return false; };
  void setPunctAt(unsigned int index, std::string punct)
    { if (_words && (index < _nWords)) _words[index].f_word_punct = punct; };
  std::string punctAt(unsigned int index)
    { return (_words && (index < _nWords)) ? _words[index].f_word_punct : ""; };

  bool hasPos(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_pos.empty(); } else return false; };
  void setPosAt(unsigned int index, std::string pos)
 	{ if (_words && (index < _nWords)) _words[index].f_word_pos = pos; };
  std::string posAt(unsigned int index)
 	{ return (_words && (index < _nWords)) ? _words[index].f_word_pos : ""; };

  //Internal normalization methods
  void setNorm(bool status) { _isnorm = status; };
  bool hasNorm(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_norm.empty(); } else return false; };
  void setNormAt(unsigned int index, std::string norm)
  	{ if (_words && (index < _nWords)) _words[index].f_word_norm = norm; };

  bool hasNormPrePunct(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_norm_prepunct.empty(); } else return false; };
  void setNormPrePunctAt(unsigned int index, std::string norm_prepunct)
  	{ if (_words && (index < _nWords)) _words[index].f_word_norm_prepunct = norm_prepunct; };

  bool hasNormPunct(unsigned int index)
    { if (_words && (index < _nWords)) { return !_words[index].f_word_norm_punct.empty(); } else return false; };
  void setNormPunctAt(unsigned int index, std::string norm_punct)
  	{ if (_words && (index < _nWords)) _words[index].f_word_norm_punct = norm_punct; };

  //External normalization methods
  bool isNorm() { return _isnorm; };
  std::string normAt(unsigned int index)
  	{ return (_words && (index < _nWords)) ? _words[index].f_word_norm : ""; };
  std::string normPrePunctAt(unsigned int index)
  	{ return (_words && (index < _nWords)) ? _words[index].f_word_norm_prepunct : ""; };
  std::string normPunctAt(unsigned int index)
  	{ return (_words && (index < _nWords)) ? _words[index].f_word_norm_punct : ""; };

  int timeAt(unsigned int index)
    { return (_words && (index < _nWords)) ? _words[index].f_final_time : -1; };
  float scoreAt(unsigned int index)
    { return (_words && (index < _nWords)) ? _words[index].f_score : (float)kMaxCost; };
  float confidenceAt(unsigned int index)
    { return (_words && (index < _nWords)) ? _words[index].f_confidence : 0.0f; };
  int durationOf(unsigned int index)
  	{ return (_words && (index < _nWords)) ? _words[index].f_length : 0; };
  char* tagAt(unsigned int index)
  {
  	if ((index < 0) || (index > _nTags)) return (char*)"";

  	unsigned int acc = 0;
  	for (unsigned int i = 0; i < _nWords; i++)
  	{
  		for (unsigned int j = 0; j < _words[i].f_tags.size(); j++)
  		{
  			//Ignore control tags
  			std::string tagStr(_words[i].f_tags[j]);
  			if (tagStr.empty() == false) {
  				if ((tagStr.at(0) == TAG_START) || (tagStr.at(0) == TAG_END)) {
  					continue;
  				}
  				else {
  					if (acc == index)
  						return (char*)_words[i].f_tags[j].c_str();
  					else {
  						acc += 1;
  					}
  				}
  			}
			else {
				acc += 1;
			}
  		}
  	}

  	return (char*)"";//error!
  };

  //Copy this DecoderResult into a new DecoderResult
  DecoderResult* clone();

  virtual ~DecoderResult() {
    delete [] _phones;  // decoded phone sequence
    delete [] _words;  //decoded word sequence
    delete [] _audio;
    delete [] _features;
    delete [] _targets;

    //Propagate delete to all nBests
    delete _next_nbest_list;
  };

  void printPhones(std::ostream& outStream);
  void printWords(std::ostream& outStream);
  void printResult(std::ostream& outStream);

  void printPhoneTargets(std::ostream& outStream);
  void printDistTargets(std::ostream& outStream);
  void printTargets(std::ostream& outStream, std::shared_ptr<std::map<int, int>> phoneTranslationTable);
  std::list<int> getTargets(std::shared_ptr<std::map<int, int>> phoneTranslationTable);

  //Getters and Setters para o tempo de inicio e de fim da frase (tempos do Endpoint em cSecs)
  void setSentenceStartTime(long sentenceStartTime) { _sentenceStartTime = sentenceStartTime; };
  void setSentenceEndTime(long sentenceEndTime) { _sentenceEndTime = sentenceEndTime; };
  long getSentenceStartTime() {return _sentenceStartTime; };
  long getSentenceEndTime() {return _sentenceEndTime; };

  //Return the sentence as a string
  std::string getText();

  //Gets textual representation of the result
  std::string getFullDescription();

  //Return the sentence as a normalized  string
  std::string getNormalizedText();

  //Gets normalized textual representation of the result
  std::string getNormalizedFullDescription();

  int nPhones() { return _nPhones; };
  CDecodedPhoneInfo* phoneInfoAt(unsigned int i) { return (_phones && (i < _nPhones)) ? &_phones[i] : NULL; };
  CDecodedWordInfo* wordInfoAt(unsigned int i) { return (_words && (i < _nWords))? &_words[i] : NULL; };
  std::string phoneAt(unsigned int index) { return (_phones && (index < _nPhones)) ? _phones[index].f_arc_string : ""; };

  void setTaskName(std::string name) { _taskName = name; };
  std::string getTaskName() { return _taskName; };

  void setLatency(double latency) { _latency = latency; };
  double getLatency() { return _latency; };

  long getAudioSize() { return _audioSize; };
  char* getAudio()    { return _audio; };
  void setAudio(char* audio, long size) { delete[] _audio; _audio = audio; _audioSize = size; };

  long getFeaturesSize() { return _featuresSize; };
  float* getFeatures()	 { return _features; };
  void setFeatures(float* features, long size) { delete[] _features; _features = features; _featuresSize = size; };

  long getTargetsCount() { return _targetsCount; };
  int* getTargets()	 { return _targets; };
  void setTargets(int* targets, long size) { delete[] _targets; _targets = targets; _targetsCount = size; };

  float getTokenCost() { return _tok_cost; };
  void setTokenCost(float cost) { _tok_cost = cost; };

  void setGenderId(int id) { _genderId = id; };
  int getGenderId() { return _genderId; };

  void setGenderConf(float conf) { _genderConf = conf; };
  float getGenderConf() { return _genderConf; };

  void setSpeakerId(int id) { _speakerId = id; };
  int getSpeakerId() { return _speakerId; };

  void setSpeakerIdConf(float conf) { _speakerIdConf = conf; };
  float getSpeakerIdConf() { return _speakerIdConf; };

  void setSpeakerName(std::string name) { _speakerName = name; };
  std::string getSpeakerName() { return _speakerName; };

  void setSpeakerHash(std::string hash) { _speakerHash = hash; };
  std::string getSpeakerHash() { return _speakerHash; };

  void setSpeakerTurn(int turn) { _speakerTurn = turn; };
  int getSpeakerTurn() { return _speakerTurn; };

  void setSpeakerKnown(bool known) { _speakerKnown = known; };
  bool isSpeakerKnown() { return _speakerKnown; };

  void setLangId(std::string id) { _langId = id; };
  std::string getLangId() { return _langId; };

  void setLangIdConf(float conf) { _langIdConf = conf; };
  float getLangIdConf() { return _langIdConf; };


private:
  bool _executableTagsPresent;


	//round up a float type and show one decimal place
	int rndFloat(float n) {
		return n - std::floor(n) >= 0.5 ? (int)std::ceil(n) : (int)std::floor(n);
	};

public:
  /**
   * From: http://discuss.joelonsoftware.com/default.asp?joel.3.325282.13
   *
   * Also available in StringUtils.
   * This function is replicated here to avoid linking
   * external applications with AudimusUtils.lib
   */
  std::string Latin1toUTF8( const char* szStr )
  {
    const unsigned char* pSource = (const unsigned char*)szStr;
    std::string strResult;
    int nLen = strlen( szStr );
    strResult.reserve( nLen + nLen/10 );
    int cSource = *(pSource);
    while ( cSource )
    {
      if ( cSource >= 128 )
      {
        strResult += (char)(((cSource&0x7c0)>>6) | 0xc0);
        strResult += (char)((cSource&0x3f) | 0x80);
      }
      else
        strResult += cSource;
      cSource = *(++pSource);
    }
    return strResult;
  };

};

} //namespace audimus

#endif /* _DECODER_RESULT_H */
