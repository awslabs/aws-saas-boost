#ifndef _AUDIMUS_EVENT_LISTENER_H
#define _AUDIMUS_EVENT_LISTENER_H

#include "Event.h"

namespace audimus {

/**
 * Classe abstracta que define o que � um listener de eventos
 */
class EventListener {
public:	
	virtual void eventOcurred(Event* event) = 0;
	virtual ~EventListener() {};
};

}

#endif /* _AUDIMUS_EVENT_LISTENER_H */
