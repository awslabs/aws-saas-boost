#ifndef _AUDIMUS_DLL_H
#define _AUDIMUS_DLL_H

/**
 * Interface do DLL de acesso ao Audimus.
 * Esta interface pode ser usada para exportar os entry-point
 * para a DLL (#define DLL_EXPORT). Caso contr�rio o
 * compilador ir� assumir que se pretende compilar uma
 * aplica��o cliente, logo esta � a interface importada
 *
 */


#ifdef _WINDOWS
	#if defined(EXPORT_TO_DLL)
		#define DllSpec __declspec(dllexport)
	#else
		#define DllSpec __declspec(dllimport)
	#endif
#else
	#define DllSpec
#endif

//C++ includes
#include <string>
#include <vector>

#include "EventListener.h"
#include "Error.h"

#include "UserDescriptor.h"
#include "TaskDescriptor.h"


namespace audimus {

//Defini��o do tipo de dados dados dos handles para os reconhecedores
typedef int AudimusHandle;

#define AUDIMUS_NO_HANDLE -1

/**
 * M�todo que possibilita a gest�o de diversos
 * reconhecedores em paralelo. Com este m�todo
 * obtenho uma senha de utiliza��o para um novo
 * reconhecedor
 */
DllSpec audimus::AudimusHandle audimus_getNewHandle();


/**
 * M�todo que procede � liberta��o dos recursos
 * atribuidos a um reconhecedor
 */
DllSpec audimus::errorCode audimus_releaseHandle(audimus::AudimusHandle handle);

/**
 * M�todo que procede � inicializa��o do ASR
 */
DllSpec int audimus_allocate(audimus::AudimusHandle handle);

/**
 * M�todo que inicia o processo de reconhecimento
 */
DllSpec audimus::errorCode audimus_start(audimus::AudimusHandle handle);


/**
 * M�todo que para o processo de reconhecimento
 */
DllSpec audimus::errorCode audimus_interrupt(audimus::AudimusHandle handle);

/**
 * M�todo que suspende no fim da frase actualmente
 * em processamento, o reconhecimento
 */
DllSpec audimus::errorCode audimus_pause(audimus::AudimusHandle handle);

/**
 * M�todo que finaliza as estruturas alocadas para reconhecimento
 */
DllSpec audimus::errorCode audimus_deallocate(audimus::AudimusHandle handle);

/**
 * Registo um event listener (para os resultados do reconhecimento)
 */
DllSpec audimus::errorCode audimus_registerRecognitionListener(audimus::EventListener* listener, audimus::AudimusHandle handle);

/**
 * Des-Registo um event listener
 */
DllSpec audimus::errorCode audimus_unRegisterRecognitionListener(audimus::EventListener* listener, audimus::AudimusHandle handle);

/**
 * Escrevo um bloco de audio para ser processado pelo Audimus
 */
DllSpec int audimus_write(char* buffer, int offset, int length, audimus::AudimusHandle handle);

/**
 * Limpo os buffers de entrada de audio do Audimus
 * (idealmente usado quando se est� a fazer srteaming de audio
 * para o Audimus a partir de ficheiros e n�o se pretende guardar
 * dados entre os v�rios ficheiros).
 */
DllSpec audimus::errorCode audimus_flush(bool autoPause, audimus::AudimusHandle handle);

/**
 * Processo o ficheiro e reconheco o conteudo.
 * Os resultados s�o enviados para os EventListeners
 */
DllSpec audimus::errorCode audimus_recognizeFile(std::string& filepath, audimus::AudimusHandle handle);

/**
 * M�todo que permite definir um ficheiro com a arquitectura a carregar
 */
DllSpec audimus::errorCode audimus_setArchitectureFilePath(std::string& configPath, audimus::AudimusHandle handle);

/**
 * Defino um parametro para o reconhecedor
 */
DllSpec bool audimus_setParameter(std::string& name, std::string& value, audimus::AudimusHandle handle);

/**
 * Devolvo o valor dum parametro do reconhecedor
 */
DllSpec std::string audimus_getParameter(std::string& name, audimus::AudimusHandle handle);

/**
 * Verifico se o engine est� num sub-estado de allocated
 */
DllSpec bool audimus_isAllocated(audimus::AudimusHandle handle);


////////////////////////////////////////////////////////////////////////////////
//
// M�todos para manipula��o do modelo ac�stico
////////////////////////////////////////////////////////////////////////////////


/**
 * Registo um novo modelo ac�stico
 * N�o ser� armazenada uma refer�ncia interna para o objecto user (UserDescriptor)
 */
DllSpec audimus::errorCode audimus_registerUser(UserDescriptor& user, audimus::AudimusHandle handle);

/**
 * Desregisto um modelo acustico previamente registado
 */
DllSpec audimus::errorCode audimus_unregisterUser(std::string& username, audimus::AudimusHandle handle);

/**
 * Verifico se um user j� est� registado
 */
DllSpec bool audimus_isUserRegistered(std::string& name, audimus::AudimusHandle handle);

/**
 * Activo o modelo de um dado user
 */
DllSpec audimus::errorCode audimus_activateUser(std::string& username, audimus::AudimusHandle handle);

/**
 * Devolvo o nome dos modelos acusticos registados
 */
DllSpec std::vector<std::string> audimus_getUserModels(audimus::AudimusHandle handle);

/**
 * Devolvo o nome dos modelos acustico loaded
 */
DllSpec std::vector<std::string> audimus_getLoadedUsers(audimus::AudimusHandle handle);


////////////////////////////////////////////////////////////////////////////////
//
// M�todos para manipula��o do modelos de linguagem / tarefas / gram�ticas
////////////////////////////////////////////////////////////////////////////////

/**
 * Registo uma nova tarefa
 */
DllSpec audimus::errorCode audimus_registerTask(TaskDescriptor& task, audimus::AudimusHandle handle);

/**
 * Registo uma nova tarefa (dado um ficheiro XML e um direct�rio onde est�o os modelos de fones)
 * Se a extens�o do ficheiro grammar for .txt ent�o a tarefa ser� �til para alinhamento
 */
DllSpec audimus::errorCode audimus_registerTask(std::string& taskName, std::string& grammarFile, std::string& modelsDir, audimus::AudimusHandle handle);

/**
 * Compiles an input SRGS-XML grammar
 */
DllSpec audimus::TaskDescriptor* audimus_compileSRGS(std::string& xmlFilename, std::string& taskName, std::string& outputDir, bool uniqueFilenames, AudimusHandle handle);

/**
 * Generates a lexicon to a given vocabulary and phone models dir
 */
DllSpec bool audimus_generateLexicon(audimus::TaskDescriptor* taskDescriptor, std::string& modelsDir, char* silenceWord, bool preCompileModel, AudimusHandle handle);

/**
 * Generates a lexicon to a TaskDescriptor given a phone models dir
 */
DllSpec bool audimus_generateLexicon(std::vector<std::string>& vocabulary, std::string& modelsDir, std::string& silenceWord, std::string& lexiconOutFile, AudimusHandle handle);

/**
 * Verifico se uma tarefa com dado nome j� est� registado
 */
DllSpec bool audimus_isTaskRegistered(std::string& name, audimus::AudimusHandle handle);

/**
 * Desregisto uma tarefa previamente registada
 */
DllSpec audimus::errorCode audimus_unregisterTask(std::string& taskname, audimus::AudimusHandle handle);

/**
 * Carrego para mem�ria uma dada tarefa
 * Este m�todo poder� demorar algum tempo, dependento do tamanho da tarefa
 */
DllSpec audimus::errorCode audimus_loadTask(std::string& taskname, audimus::AudimusHandle handle);

/**
 * Vou retirar da mem�ria uma tarefa previamente carregada
 */
DllSpec audimus::errorCode audimus_unloadTask(std::string& taskname, audimus::AudimusHandle handle);

/**
 * Vou activar uma dada tarefa.
 */
DllSpec audimus::errorCode audimus_activateTask(std::string& taskname, audimus::AudimusHandle handle);

/**
 * Vou activar v�rias tarefas.
 */
DllSpec audimus::errorCode audimus_activateTasks(std::vector<std::string>& tasknames, audimus::AudimusHandle handle);

/**
 * Activa��o de tarefas, com pesos individuais
 */
DllSpec audimus::errorCode audimus_activateTasks(std::vector<std::string>& tasknames, std::vector<float>& weights, audimus::AudimusHandle handle);

/**
 * Obtenho o nome das tarefas geridas pelo ASR
 */
DllSpec std::vector<std::string> audimus_getTasknames(audimus::AudimusHandle handle);

/**
 * Vou saber se uma dada tarefa j� est� carregada
 */
DllSpec bool audimus_isTaskLoaded(std::string& taskname, audimus::AudimusHandle handle);

/**
 * Vou saber se uma dada tarefa est� em uso
 */
DllSpec bool audimus_isTaskActivated(std::string& taskname, audimus::AudimusHandle handle);

//Estados possiveis do reconhecedor
enum EngineState {STATE_DEALLOCATED = 0, STATE_ALLOCATING_RESOURCES,
				  STATE_DEALLOCATING_RESOURCES, STATE_SUSPENDED,
				  STATE_LISTENING, STATE_PROCESSING};


/**
 * M�todo que permite saber o estado actual dum reconhecedor
 */
DllSpec EngineState audimus_getState(audimus::AudimusHandle handle);

/**
 * M�todo que permite esperar que o engine atinga um dado estado
 */
DllSpec bool audimus_waitForState(EngineState state, audimus::AudimusHandle handle);

/*
 * M�todo que permite obter parametros sobre uma licen�a
 */
DllSpec std::string audimus_getLicenseParameter(const std::string &macrocomponent, const std::string &parameter);

/*
 * M�todo que permite ativar uma licen�a
 */
DllSpec int audimus_activateLicense(std::string& license, std::string& info, std::string& activation, std::string& proxy_host, int proxy_port, std::string& proxy_user, std::string& proxy_pass, int force, int asService);

}

#endif /* _AUDIMUS_DLL_H */
