#ifndef _AUDIMUSTOOLS_DLL_H
#define _AUDIMUSTOOLS_DLL_H

/**
 * Interface do DLL de acesso aos utilit�rios do Audimus.
 * Esta interface pode ser usada para exportar os entry-point 
 * para a DLL (#define DLL_EXPORT). Caso contr�rio o
 * compilador ir� assumir que se pretende compilar uma
 * aplica��o cliente, logo esta � a interface importada
 * 
 */

#ifdef _WINDOWS
	#if defined(EXPORT_TO_DLL)
		#define DllSpec __declspec(dllexport)
	#else
		#define DllSpec __declspec(dllimport)
	#endif
#else
	#define DllSpec 	
#endif

//C++ includes 
#include <string>
#include <list>

//#include "TaskDescriptor.h"

namespace audimus {

//Defini��o do tipo de dados dados dos handles para os m�dulos
typedef int AudimusHandle;


/**
 * Inicializa o acesso a opera��es protegidas no Dll
 */
//DllSpec bool init(std::string& value);

/**
 * Dado um conjunto de ficheiros de features, gera o pfile respectivo
 */
DllSpec bool mergeFeatures(std::list<std::string>& featureFiles, int frameSize, std::string& pfilename);

//DllSpec TaskDescriptor* createTask(std::list<std::string>& sentences, std::string& taskname, std::string& outputDir, std::string& modelsDir);

//DllSpec TaskDescriptor* createTaskFromXML(std::string& xmlFilename, std::string& taskName, std::string& outputDir, std::string& modelsDir);

/**
 * @todo Deprecated: is now in AudimusAPI
 */
//DllSpec bool generateLexicon(std::list<std::string>& dictionary, std::string& modelsDir, std::string& lexiconOutFile);

//Audio control
DllSpec bool setCaptureVolume(int newVolume, int deviceId);
DllSpec int getCaptureVolume(int deviceId);
DllSpec std::string getCaptureDeviceName(int deviceId);

//ResultsExtractor operations
DllSpec int getResultsExtactorHandle(std::string& fstLmPath, std::string& vocabPath);
DllSpec void releaseResultsExtactorHandle(int handle);
DllSpec std::list<std::string> extractNLSMLResults(int handle, std::string& inputSentence);
DllSpec std::list<std::string> extractTextResults(int handle, std::string& inputSentence);

// Align Tools
DllSpec bool align(const std::string& reference, const std::string& hypothesis, std::string& alignment);
DllSpec bool normalize(const std::string& input, const std::string& language, const std::string& country, const std::string& domain, const std::string& profile, const std::string& encoding, const std::list<std::string>& managers, std::string& alignment, bool ignore_case = true, bool ignore_punct = true);
DllSpec bool normalizeAndAlign(const std::string& reference, const std::string& hypothesis, const std::string& language, const std::string& country, const std::string& domain, const std::string& profile, const std::string& encoding, const std::list<std::string>& managers, std::string& alignment, bool ignore_case = true, bool ignore_punct = true);

} //namespace audimus

#endif //_AUDIMUSTOOLS_DLL_H
