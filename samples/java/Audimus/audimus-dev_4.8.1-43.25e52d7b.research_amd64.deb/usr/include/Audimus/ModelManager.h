#ifndef MODELMANAGER_H_
#define MODELMANAGER_H_

//STL includes
#include <string>
#include <vector>
#include <list>

//Audimus includes
#include "TaskDescriptor.h"
#include "UserDescriptor.h"

namespace audimus {

class ModelManager 
{
public:
	//Avoid compile warning of no virtual destructor...
	virtual ~ModelManager() {};

	///////////////////////////////////////////////////////////////////////////
	// M�todos para manipula��o de tasks (gram�ticas)
	///////////////////////////////////////////////////////////////////////////	
	//Registo uma nova tarefa
	virtual errorCode registerTask(TaskDescriptor& descriptor) = 0;

	//Registo uma nova tarefa (a partir de XML)
	virtual errorCode registerTask(std::string& taskName, std::string& grammarFile, std::string& modelsDir) = 0;
	
	//Compiles SRGS grammar without generating lexicon
	virtual TaskDescriptor* compileSRGS(std::string& xmlFilename, std::string& taskName, std::string& outputDir, bool uniqueFilenames) = 0;

	//Generates lexicon for a TaskDescriptor according to he characteristics of given a G2P models dir
	virtual bool generateLexicon(TaskDescriptor* taskDescriptor, std::string& modelsDir, char* silenceWord, bool preCompileModel) = 0;

	//Generates a lexicon to a TaskDescriptor given a phone models dir
	virtual bool generateLexicon(std::list<std::string>& vocabulary, std::string& modelsDir, std::string& silenceWord, std::string& lexiconOutFile) = 0;

	//Verifico se uma tarefa j� est� registada
	virtual bool isTaskRegistered(std::string& name) = 0;

	//Desregisto uma tarefa
	virtual errorCode unregisterTask(std::string& taskname) = 0;

	//Fa�o o load duma tarefa previamente registada
	virtual errorCode loadTask(std::string& taskname) = 0;
	
	//Fa�o o unload duma tarefa previamente registada e carregada
	virtual errorCode unloadTask(std::string& taskname) = 0;

	//Activo uma tarefa
	virtual errorCode activateTask(std::string& taskname) = 0;
	virtual errorCode activateTasks(std::vector<std::string>& tasknames) = 0;
	virtual errorCode activateTasks(std::vector<std::string>& tasknames, std::vector<float>& weights) = 0;
	
	//Devolvo o nome de todas as tarefas
	virtual std::vector<std::string> getTasknames() = 0;
	
	//Devolvo o nome das tarefas carregada
	virtual bool isTaskLoaded(std::string& taskname) = 0;

	//Devolvo o nome das tarefas em uso
	virtual bool isTaskActivated(std::string& taskname) = 0;

	///////////////////////////////////////////////////////////////////////////
	// M�todos para manipula��o de users (modelos acusticos)
	///////////////////////////////////////////////////////////////////////////

	//Registo um novo user
	virtual errorCode registerUser(UserDescriptor& descriptor) = 0;

	//Desregisto um user
	virtual errorCode unregisterUser(std::string& username) = 0;
	
	//Verifico se um user j� est� registado
	virtual bool isUserRegistered(std::string& name) = 0;

	//Fa�o o load dum user previamente registado (est� implicito o unload do user actual)
	virtual errorCode activateUser(std::string& username) = 0;
	
	//Devolvo o nome dos modelos acusticos registados
	virtual std::vector<std::string> getUserModels() = 0;
	
	virtual std::vector<std::string> getLoadedUsers() = 0;
	
	//Devolvo os descritores dos modelos acusticos registados
	////virtual std::vector<UserDescriptor> getUserDescriptors() = 0;
};

} //namespace audimus

#endif /*MODELMANAGER_H_*/
