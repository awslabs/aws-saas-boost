#ifndef _OUTPUTBUFFER_H
#define _OUTPUTBUFFER_H

#include "Item.h"

namespace audimus {

/** 
 * Output buffer
 *	- Used for components write data
 */
class OutputBuffer 
{
 protected:
 	int _frameBodySize;
 public:
  OutputBuffer(int frameBodySize) {
	  _frameBodySize = frameBodySize;
   };
  virtual ~OutputBuffer(){};

  virtual int getBodySize(){ return _frameBodySize; }
  virtual int getFloatBodySize(){ return (int)(_frameBodySize/sizeof(float)); }
  virtual int getShortBodySize(){ return (int)(_frameBodySize/sizeof(short)); }
  virtual long clear() = 0;
  virtual bool write(Item* item) = 0;
  virtual int getAvailableSpace() = 0;
};

} //namespace audimus

#endif //_OUTPUTBUFFER_H
