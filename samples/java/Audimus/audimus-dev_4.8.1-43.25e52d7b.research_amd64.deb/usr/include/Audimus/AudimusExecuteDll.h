#ifndef _AUDIMUSEXECUTE_DLL_H
#define _AUDIMUSEXECUTE_DLL_H

/**
 * Interface do DLL de acesso audimus-execute.
 * Esta interface pode ser usada para exportar os entry-point
 * para a DLL (#define DLL_EXPORT). Caso contr�rio o
 * compilador ir� assumir que se pretende compilar uma
 * aplica��o cliente, logo esta � a interface importada
 *
 */

#ifdef _WINDOWS
	#if defined(EXPORT_TO_DLL)
		#define DllSpec __declspec(dllexport)
	#else
		#define DllSpec __declspec(dllimport)
	#endif
#else
	#define DllSpec
#endif

//C++ includes
#include <string>

#include "Error.h"
#include "EventListener.h"
#include "InputBuffer.h"
#include "OutputBuffer.h"
#include "ModelManager.h"

namespace audimus {


//Defini��o do tipo de dados dados dos handles para os m�dulos
typedef int AudimusHandle;

//#############################################################################
//
// Common Modules Interface
//
//#############################################################################

/**
 * Obtenho o handle para um m�dulo carregado a partir dum XML
 */
DllSpec AudimusHandle loadFromXML(std::string& xmlFileName);

/**
 * Liberto o handle previamente alocado para manipula��o dum m�dulo
 */
DllSpec errorCode releaseHandle(AudimusHandle handle);

DllSpec bool setParameter(std::string& name, std::string& value, AudimusHandle handle);

DllSpec std::string getParameter(std::string& name, AudimusHandle handle);

DllSpec errorCode registerListener(EventListener* listener, AudimusHandle handle);

DllSpec errorCode unRegisterListener(EventListener* listener, AudimusHandle handle);

DllSpec errorCode start(AudimusHandle handle);

DllSpec errorCode pause(AudimusHandle handle);

DllSpec errorCode write(char* buffer, int offset, int length, AudimusHandle handle);

DllSpec errorCode flush(bool autoPause, AudimusHandle handle);

DllSpec errorCode setInput(InputBuffer* inBuffer, AudimusHandle handle);

DllSpec errorCode setOutput(OutputBuffer* outBuffer, AudimusHandle handle);

DllSpec errorCode wait(AudimusHandle handle);

DllSpec errorCode requestExit(AudimusHandle handle);

DllSpec ModelManager* getModelManager(AudimusHandle handle);

DllSpec errorCode interrupt(AudimusHandle handle);

DllSpec errorCode process(std::string& inFile, AudimusHandle handle);

DllSpec std::string getLicenseParameter(const std::string &macrocomponent, const std::string &parameter);

DllSpec int activate(std::string& license, std::string& info, std::string& activation, std::string& proxy_host, int proxy_port, std::string& proxy_user, std::string& proxy_pass, int force, int asService);

} //namespace

#endif //_AUDIMUSEXECUTE_DLL_H
