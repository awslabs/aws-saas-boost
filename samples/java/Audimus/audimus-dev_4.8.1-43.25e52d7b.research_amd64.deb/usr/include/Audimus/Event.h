#ifndef _AUDIMUS_EVENT_H
#define _AUDIMUS_EVENT_H

#include <map>
#include <string>
#include <time.h>

namespace audimus {

//Lista de eventos admissiveis no sistema

//Eventos associados ao ENDPOINT
#define ENDPOINT_SOS            	100
#define ENDPOINT_EOS		    	101
#define ENDPOINT_ENERGY         	102
#define ENDPOINT_NONSP_SOS      	103
#define ENDPOINT_NONSP_EOS			104
#define ENDPOINT_NONSP_REPORT		105
#define ENDPOINT_AEC_REPORT			106
#define ENDPOINT_DIARIZATIOM_SOS	107
#define ENDPOINT_DIARIZATIOM_EOS	108
#define ENDPOINT_DECODER_SOS		109
#define ENDPOINT_DECODER_EOS		110
#define ENDPOINT_CAPPUNCT_SOS		111
#define ENDPOINT_CAPPUNCT_EOS		112
#define ENDPOINT_SD_REPORT          113
#define ENDPOINT_MUSIC_SOS      	114
#define ENDPOINT_MUSIC_EOS			115
#define ENDPOINT_NONMUSIC_SOS      	116
#define ENDPOINT_NONMUSIC_EOS		117

//Eventos associados ao RASTA (gama 2xx)
//-

//Eventos associados ao DTW
#define DTW_FOUND 300

//Eventos associados ao ForwardMLP / NNS (gama 4xx)
//-
#define NNS_EPOCH_TIME 	    400
#define NNS_TRAIN_EVAL    401

//Eventos associados ao FSTDecoder
#define CBID_DECODER_RESULT 500
#define CBID_DECODER_TEMP_RESULT 501

//Eventos associados ao Jingle/Threshold
#define JINGLE_DETECTED 	    600
#define THRESHOLD_FINAL_RESULTS 601
#define EXIT_JINGLE				602

//Eventos associados ao Localizador (GCC_Phat)
#define GCCPHAT_ANGLE	700

// Eventos associados ao Averager
#define AVERAGER 800

//Eventos associados ao JINGLE
#define JINGLE_SOS      900
#define JINGLE_EOS	    901

//Eventos associados �s transi��es de estados ao nivel da API
#define EVENT_ALLOCATING_RESOURCES 1000
#define EVENT_DEALLOCATING_RESOURCES 1001
#define EVENT_DEALLOCATED 1002
#define EVENT_SUSPENDED 1003
#define EVENT_LISTENING 1004
#define EVENT_PROCESSING 1006

//Eventos associados ao SSNTTopicSegmentation
#define EVENT_TOPIC 1100
#define TOPIC 0

//Eventos de envio de TranscriptSegments
#define EVENT_TRANSCRIPTSEGMENT	1200
#define TRANSCRIPTSEGMENT_FIELD	0

//Eventos associados ao AEC (gama 3xxx)
#define EVENT_PROPERTY_AEC_SENTENCE 3000
#define EVENT_PROPERTY_AEC_SEGMENT 3001
#define EVENT_PROPERTY_AEC_START_TIME 3002
#define EVENT_PROPERTY_AEC_END_TIME 3003
#define EVENT_PROPERTY_AEC_CONFIDENCE 3004
#define EVENT_PROPERTY_AEC_NAME 3005

//Eventos associados ao Spot Detection (gama 4xxx)
#define EVENT_PROPERTY_SD_START_TIME 4002
#define EVENT_PROPERTY_SD_END_TIME 4003
#define EVENT_PROPERTY_SD_CONFIDENCE 4004
#define EVENT_PROPERTY_SD_NAME 4005
#define EVENT_PROPERTY_SD_INDEX 4006

////////////////////////////////////////////////////////
//A um evento podem estar associados v�rias propriedades
//que s�o enviadas em campos indexados por um ID. 
//A seguinte lista � a defini��o de IDs para essas infos

#define JINGLE_FIELD_STREAM_POS 0

#define ENDPOINT_FIELD_STREAM_POS 0  // frame where event happened
#define ENDPOINT_CONFIDENCE 1        // confidence measure of event
#define ENDPOINT_SENTENCE_ID 2       // sentence id of the event
#define ENDPOINT_HYP_ID 3			 // hypothesis id
#define ENDPOINT_TIMESTAMP 4	     // Event Time Stamp
#define ENDPOINT_DECODER_INIT 5 	 // Decoder Initialization delay
#define ENDPOINT_SEGMENT_ID 6       // Segment id of the event

#define ENDPOINT_FIELD_ENERGY 0

#define ENDPOINT_FIELD_NONSP_REPORT_SENTENCE 0
#define ENDPOINT_FIELD_NONSP_REPORT_SEGMENT 1
#define ENDPOINT_FIELD_NONSP_REPORT_TIME 2

#define AVERAGER_SENTENCE 0
#define AVERAGER_TYPE 1              // 0 = gender (male, female);
                                     // 1 = background (clean, music, noise);
                                     // 2 = speaker id male;
                                     // 3 = speaker id female;
                                     // 4 = speaker cluster male;
                                     // 5 = speaker cluster female;
                                     // 6 = channel (wide, narrow);

#define AVERAGER_CLASS 2
#define AVERAGER_CONFIDENCE 3


#define NNS_EPOCH_TIME_TYPE 0 		// Type of event [ 0 = training; 1 = validating/testing]
#define NNS_EPOCH_TIME_TIME 1 		// time in seconds

#define NNS_PRE_TEST_RESULT 1 		// float with pre_test frames ok (0 - 100)
#define NNS_POST_TEST_RESULT 2 		// float with post_test frames ok (0 - 100)
#define NNS_TRAIN_VEREDICT 3 		// int with qualitative eval (0 - 5)


#define GCCPATH_ANGLE_INFO 0

//////////////////////////////////////////
// ID's associados ao componente AED
//////////////////////////////////////////
// ID's de eventos
#define EVENT_AED_HIT 2000 /* detectado um hit na stream */
#define EVENT_AED_POS 2001 /* informa��o da posi��o atual na stream */

// ID's de propriedades
#define EVENT_PROPERTY_AED_WINDOW                0 /* janela em que ocorreu a deteccao */
#define EVENT_PROPERTY_AED_HIT_WINDOW            1 /* janela do hit */
#define EVENT_PROPERTY_AED_HIT_SCORE             2 /* score do hit */
#define EVENT_PROPERTY_AED_HIT_TIME              3 /* timestamp do hit */
#define EVENT_PROPERTY_AED_REFERENCE_IDENTIFIER  4 /* identificador da referencia detectada */
#define EVENT_PROPERTY_AED_REFERENCE_DESCRIPTION 5 /* descricao da referencia detectada */
#define EVENT_PROPERTY_AED_WINDOW_SHIFT          6 /* window shift em frames */
#define EVENT_PROPERTY_AED_HIT_DELTA             7 /* erro do hit em segundos */

//////////////////////////////////////////


/**
 * Classe que descreve um evento
 */
class Event {
	private:
		std::map<int, std::string> _info;
		int _ID;
		time_t _time;
	public:
		Event(int ID) {
			_ID=ID;
			time(&_time);
		};
		virtual ~Event(){};
		int getID(){
			return _ID;
		};
		void setInfo(int ID, std::string value) {
			_info[ID]=value;
		};
		std::string getInfo(int ID){
			return _info[ID];
		};
		time_t getTime() { return _time; };
};

} //namespace audimus

#endif // _AUDIMUS_EVENT_H
