//      LAPACK++ (V. 1.1)
//      (C) 1992-1996 All Rights Reserved.

#ifndef _LAPACK_H_
#define _LAPACK_H_

#include "arch.h"
#include "f2c.h"
#include "lapackd.h"
#include "lapackc.h"

#endif
// _LAPACK_H_
